#ifndef NN_UTILS_HPP
#define NN_UTILS_HPP

#include <iostream>
#include <random>

// Object for handling 2D arrays
class TwoDWrapper {
public:
	int rows = 0;
	int cols = 0;
	double* array = nullptr;

public:
	TwoDWrapper(int rows, int cols, double* array) {
		this->rows = rows;
		this->cols = cols;
		this->array = array;
	}

	double get(int index) {
		return array[index];
	}

	void getRow(int row, double* output) {
		for (int i = 0; i < cols; i++) {
			output[i] = array[i + (cols * row)];
		}
	}

	void getCol(int col, double* output) {
		std::cout << "\n[TwoDWrapper.getCol] Not Yet Implemented\n";
	}
};

// Function Prototypes
void arrayAdd(double* base, double* add, int length);

void arraySub(double* base, double* sub, int length);

void copyArray(double* toCopy, double* dst, int size);

void displayArray(std::string msg, double* array, int rows, int cols, bool show_dim=true);

void dot(double* arrayOne, double* arrayTwo, double* result, 
	     int input_cnt, int output_cnt);

void generateRandArray(double* arr, int size);

double sigmoid(double x);

double sigmoid_derivative(double x);

void transpose(double* array, double* transposed, int M, int N);

void zeroArray(double* array, int size);
#endif