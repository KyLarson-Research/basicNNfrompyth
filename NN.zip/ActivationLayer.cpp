#ifndef ACTIVATION_LAYER_CPP
#define ACTIVATION_LAYER_CPP

#include "ActivationLayer.hpp"

//Constructors
ActivationLayer::ActivationLayer(int input_cnt,
	double (*activate)(double), double (*activate_prime)(double)) {

	// Setup members with constructor arguments
	this->activate = activate;
	this->activate_prime = activate_prime;

	this->input_cnt = input_cnt;

	input = new double[input_cnt];
	outputs = new double[input_cnt];
	outputs_prime = new double[input_cnt];
	back_propagation_result = new double[input_cnt];
	
	zeroArray(input, input_cnt);
	zeroArray(outputs, input_cnt);
	zeroArray(outputs_prime, input_cnt);
	zeroArray(back_propagation_result, input_cnt);
}

void ActivationLayer::backwardPropagation(double* output_err, double learning_rate) {
	// Apply activate_prime to the input
	for (int i = 0; i < input_cnt; i++) {
		back_propagation_result[i] = activate_prime(input[i]) * output_err[i];
	}
}

void ActivationLayer::clear() {
	delete[] input;
	delete[] outputs;
	delete[] outputs_prime;
	delete[] back_propagation_result;
}

void ActivationLayer::display() {
	cout << "Activation Layer: " << ID << endl;
	displayArray("Input: ", input, 1, input_cnt);
	displayArray("Output: ", outputs, 1, input_cnt);
	displayArray("Output Prime: ", outputs_prime, 1, input_cnt);
}

//Calculate activated input
void ActivationLayer::forwardPropagation(double* input) {
	// Apply activation function to every input
	for (int i = 0; i < input_cnt; i++) {
		this->input[i] = input[i];
		outputs[i] = activate(input[i]);
	}
}

#endif
