// main.cpp : Started 5-20-21 by Kyle Larson and Kyle Savery for Proto6909
//TODO insert license here
#include <chrono>
#include <random>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ConnectedLayer.hpp"
#include "NN-utils.hpp"
#include "ActivationLayer.hpp"
#include "Activations.hpp"
#include "Error.hpp"
#include "NeuralNetwork.hpp"

using namespace std;

int main()
{

    // Get start time
    auto start = chrono::system_clock::now();
    
    srand((unsigned)time(nullptr)); // Seed the rand function

    // Training Data
    int cases = 4;
    int input_size = 2;
    int output_size = 1;
    double inputs_array[8] = { 0, 0, 0, 1, 1, 0, 1, 1};
    double expected_array[4] = { 0,1,1,0 };
    TwoDWrapper input(cases, input_size, inputs_array);
    TwoDWrapper expected(cases, output_size, expected_array);
    double learning_rate = 0.1;
    int epochs = 10;

    // Create the neural network
    NeuralNetwork NN(1, meanSquaredError, meanSquaredErrorPrime);

    // Create and add layers to the network
    ConnectedLayer layer_one(2, 3); // 2 inputs, 3 outputs
    ActivationLayer layer_two(3, tan_hb, tan_hb_prime); // 3 inputs, 3 outputs
   // ConnectedLayer layer_three(3, 1); // 3 inputs, 1 output
    //ActivationLayer layer_four(1, tan_hb, tan_hb_prime); // 1 input, 1 output

    layer_one.weights[0] = -0.49543151;
    layer_one.weights[1] = -0.42657034;
    layer_one.weights[2] = -0.03819171;
    layer_one.weights[3] = -0.04611055;
    layer_one.weights[4] = 0.09963381;
    layer_one.weights[5] = -0.20917337;
    layer_one.bias[0] = -0.32333694;
    layer_one.bias[1] = -0.3446145;
    layer_one.bias[2] = -0.03605899;

   // layer_three.weights[0] = 0.36883005;
    //layer_three.weights[1] = -0.25465481;
    //layer_three.weights[2] = 0.08026713;

    //layer_three.bias[0] = -0.27740511;

    
    NN.addConnectedLayer(layer_one);
    NN.addActivationLayer(layer_two);
   // NN.addConnectedLayer(layer_three);
    //NN.addActivationLayer(layer_four);

    // Training the network
    cout << "\nBegin Training Section: \n";
    cout << "-----------------------\n\n";
    NN.train(input, expected, epochs, learning_rate);

    // Use trained network to predict output based on input
    double* predicted = new double[output_size];
    double* test = new double[input_size];
    zeroArray(predicted, output_size);
    zeroArray(test, input_size);
    input.getRow(0, test);

    NN.predict(test, predicted);

    // Output the results and compare to expected
    cout << "\nPrediction Results: \n";
    cout << "-------------------\n\nExpected: ";
    double* expected_result = new double[output_size];
    expected.getRow(0, expected_result);
    displayArray("", expected_result, 1, output_size, false);
    cout << "Actual: ";
    displayArray("", predicted, 1, output_size, false);

    // Clear allocated memory
    NN.clear();
    delete[] predicted;
    delete[] expected_result;
    delete[] test;

    // Get end time and display elapsed time
    auto end = chrono::system_clock::now();
    chrono::duration<double> elapsed = end - start;
    cout << "\n\n=============================";
    cout << "\nElapsed Time (sec): " << elapsed.count() << endl;
    cout << "=============================\n";
    
    return 0; // Return Success
}