#ifndef NEURAL_NETWORK_HPP
#define NEURAL_NETWORK_HPP

#include "Layer.hpp"
#include "ConnectedLayer.hpp"
#include "ActivationLayer.hpp"
#include <iostream>

using namespace std;

const int EPOCH_UPDATE_OCCURENCE = 1;

struct ConnectedList {
	ConnectedLayer layer;
	struct ConnectedList* next;
	struct ConnectedList* prev;
};

struct ActivationList {
	ActivationLayer layer;
	struct ActivationList* next;
	struct ActivationList* prev;
};

class NeuralNetwork{
	private:
		int ID = 0;
		int layer_cnt = 0;
		ConnectedList* conn_list = nullptr;
		ActivationList* act_list = nullptr;
		double (*error)(double, double*, int) = nullptr;
		void (*error_prime)(double*, double*, double*, int) = nullptr;

	public:
		NeuralNetwork(int ID, double (*error)(double, double*, int),
			void (*error_prime)(double*, double*, double*, int));

		void addConnectedLayer(ConnectedLayer conn_layer);

		void addActivationLayer(ActivationLayer act_layer);

		void clear();

		void display(bool show_detail=false);

		void load();

		void predict(double* input, double* dst);

		void save();

		void setError(double (*error)(double, double*, int), 
			         void (*error_prime)(double*, double*, double*, int));
		
		void train(TwoDWrapper inputs, TwoDWrapper expected, int epochs, double learning_rate);
	
	private:
		ConnectedList* clearConnectedList(ConnectedList* localPtr);

		ActivationList* clearActivationList(ActivationList* localPtr);
};

#endif