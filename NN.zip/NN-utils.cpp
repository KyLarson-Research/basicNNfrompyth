#ifndef NN_UTILS_CPP
#define NN_UTILS_CPP

#include "NN-utils.hpp"
#include "ConnectedLayer.hpp"

using namespace std;

void arrayAdd(double* base, double* add, int length) {
    for (int i = 0; i < length; i++) {
        base[i] += add[i];
    }
} 

void arraySub(double* base, double* sub, int length) {
    for (int i = 0; i < length; i++) {
        base[i] -= sub[i];
    }
}

void copyArray(double* toCopy, double* dst, int size) {
    for (int i = 0; i < size; i++) {
        dst[i] = toCopy[i];
    }
}

// Formats and displays a 1-D array with as many rows/cols as given 
void displayArray(string msg, double* array, int rows, int cols, bool show_dim) {
    if (show_dim) {
        cout << msg << "(" << rows << ", " << cols << ")" << endl;
    }
    else {
        cout << msg;
    }
    cout << "[";
    for (int element = 1; element <= rows * cols; element++) {
        cout << array[element - 1];
        if (element % cols == 0) {
            cout << "]\n";
            if (element < rows * cols) {
                cout << "[";
            }
        }
        else {
            cout << ", ";
        }
    }
}

void dot(double* A, double* B, double* result, int input_cnt, int output_cnt) {
    for (int i = 0; i < output_cnt; i++) {
        result[i] = 0.0;
        for (int k = 0; k < input_cnt; k++) {
            result[i] += A[k] * B[i + (k * output_cnt)];
        }
    }
}

void generateRandArray(double* arr, int size) {
    // Primer Rand Call
    int ignore = rand();

    for (int i = 0; i < size; i++) {
        arr[i] = (double)rand() / RAND_MAX;
    }
}

double sigmoid(double x) {
    return 1 / (1 + exp(-x));//may be a good spot to try some computations using exp to compare to python
}// e^x as in euler's function not some exponent but sometimes 2^x is substituted?

double sigmoid_derivative(double x) {
    return x * (1 - x);
}

// Array Transposition
void transpose(double* array, double* transposed, int M, int N) {
    for (int row = 0; row < M; row++) {
        for (int col = 0; col < N; col++) {
            transposed[row + col * M] = array[row * N + col];
        }
    }
}

void zeroArray(double* array, int size) {
    for (int i = 0; i < size; i++) {
        array[i] = 0.0;
    }
}

#endif