#ifndef ACTIVATION_LAYER_HPP
#define ACTIVATION_LAYER_HPP

#include "Layer.hpp"
#include "NN-utils.hpp"
#include <iostream>

using namespace std;

class ActivationLayer : public Layer {
	public:
		int input_cnt = 0;
		double (*activate)(double) = nullptr;
		double (*activate_prime)(double) = nullptr;
		double* input = nullptr;
		double* outputs = nullptr;
		double* outputs_prime = nullptr;
		double* back_propagation_result = nullptr;

	public:
		//Constructors
		ActivationLayer() {}

		ActivationLayer(int input_cnt,
			double (*activate)(double), double (*activate_prime)(double));

		void backwardPropagation(double* out_err, double learning_rate);

		void clear();

		void display();

		//Calculate activated input
		void forwardPropagation(double* input);
};

#endif
