// main.cpp : Started 5-20-21 by Kyle Larson and Kyle Savery for Proto6909
//TODO insert license here
#include <chrono>
#include <random>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ConnectedLayer.hpp"
#include "NN-utils.hpp"
#include "ActivationLayer.hpp"
#include "Activations.hpp"
#include "Error.hpp"
#include "NeuralNetwork.hpp"
#include "Test.hpp"

using namespace std;

int main()
{

    // Get start time
    auto start = chrono::system_clock::now();

    srand((unsigned)time(nullptr)); // Seed the rand function

    //Open properites file to begin training the network

    // Training Data
    int cases = 4;
    int input_size = 5;
    int output_size = 2;
    //double inputs_array[8] = { 0, 0, 0, 1, 1, 0, 1, 1};
    double inputs_array[20] = { 1, 2, 3, 4, 5,
                                0, 0, 0, 0, 0,
                                4, 7, 2, 7, 0,
                                9, 8, 7, 6, 5};
    //double expected_array[4] = { 0,1,1,0 };
    double expected_array[8] = { 1, 0, 0, 0, 1, 1, 0, 1};
    Matrix input(cases, input_size, inputs_array, DO_NOT_USE_DELETE);
    Matrix expected(cases, output_size, expected_array, DO_NOT_USE_DELETE);
    double learning_rate = 0.1;
    int epochs = 10000;

    // Create the neural network
    NeuralNetwork NN("NeuralNetworkData/NeuralNet.properties");
    //NeuralNetwork NN(1, meanSquaredError, meanSquaredErrorPrime);
    NN.setError(meanSquaredError, meanSquaredErrorPrime);
    ActivationList *temp = NN.act_list;
    while (temp != nullptr) {
        temp->layer.activate = tan_hb;
        temp->layer.activate_prime = tan_hb;
        temp = temp->next;
    }

    // Create and add layers to the network
    //ConnectedLayer layer_one(input_size, 3); // 2 inputs, 3 outputs
    //ActivationLayer layer_two(3, tan_hb, tan_hb_prime); // 3 inputs, 3 outputs
    //ConnectedLayer layer_three(3, output_size); // 3 inputs, 1 output
    //ActivationLayer layer_four(output_size, tan_hb, tan_hb_prime); // 1 input, 1 output

    //NN.addConnectedLayer(layer_one);
    //NN.addActivationLayer(layer_two);
    //NN.addConnectedLayer(layer_three);
    //NN.addActivationLayer(layer_four);
    
    // Training the network
    //NN.train(input, expected, epochs, learning_rate);

    // Use network to predict output based on input
    int case_number = 1;
    double* predicted = new double[output_size];
    double* test = new double[input_size];
    double* expected_result = new double[output_size];
 
    cout << "\nPrediction Results: \n";
    cout << "-------------------\n\n";
    for (int i = 0; i < cases; i++) {
        expected.getRow(i, expected_result);
        input.getRow(i, test);

        NN.predict(test, predicted, input_size);

        displayArray("Input: ", test, 1, input_size, false);
        displayArray("Expected Output: ", expected_result, 1, output_size, false);
        displayArray("Actual: ", predicted, 1, output_size, false);
        cout << endl;
    }

    //Shutdown the netwrok by saving its data and releasing all dynamic allocation
    NN.shutdown("NeuralNetworkData/NeuralNet.properties");

    // Clear allocated memory
    delete[] predicted;
    delete[] expected_result;
    delete[] test;

    // Get end time and display elapsed time
    auto end = chrono::system_clock::now();
    chrono::duration<double> elapsed = end - start;
    cout << "\n\n=============================";
    cout << "\nElapsed Time (sec): " << elapsed.count() << endl;
    cout << "=============================\n";
    
    return 0; // Return Success
}