// main.cpp : Started 5-20-21 by Kyle Larson and Kyle Savery for Proto6909
//TODO insert license here
#include <chrono>
#include <random>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "ConnectedLayer.hpp"
#include "NN-utils.hpp"
#include "ActivationLayer.hpp"
#include "Activations.hpp"
#include "Error.hpp"
#include "NeuralNetwork.hpp"
#include "Test.hpp"

using namespace std;

int main()
{

    // Get start time
    auto start = chrono::system_clock::now();

    srand((unsigned)time(nullptr)); // Seed the rand function

    // Training Data
    int cases = 4;
    int input_size = 2;
    int output_size = 1;
    double inputs_array[8] = { 0, 0, 0, 1, 1, 0, 1, 1};
    double expected_array[4] = { 0,1,1,0 };
    Matrix input(cases, input_size, inputs_array);
    Matrix expected(cases, output_size, expected_array);
    double learning_rate = 0.1;
    int epochs = 10000;

    // Create the neural network
    //Load from file
  /*NeuralNetwork NN("NeuralNetworkData/NeuralNet.properties");
    NN.setError(meanSquaredError, meanSquaredErrorPrime);
    ActivationList *temp = NN.act_list;
    while (temp != nullptr) {
        temp->layer.activate = tan_hb;
        temp->layer.activate_prime = tan_hb_prime;
        temp = temp->next;
    }*/

    //Create new
    NeuralNetwork NN(1, meanSquaredError, meanSquaredErrorPrime);

    // Create and add layers to the network
    ConnectedLayer layer_one(input_size, 3);
    ActivationLayer layer_two(3, tan_hb, tan_hb_prime);
    ConnectedLayer layer_three(3, output_size);
    ActivationLayer layer_four(output_size, tan_hb, tan_hb_prime);

    NN.addConnectedLayer(layer_one);
    NN.addActivationLayer(layer_two);
    NN.addConnectedLayer(layer_three);
    NN.addActivationLayer(layer_four);

    
    // Training the network
    NN.train(input, expected, epochs, learning_rate);

    // Use network to predict output based on input
    double* predicted = new double[output_size];
    double* test = new double[input_size];
    double* expected_result = new double[output_size];
 
    cout << "\nPrediction Results: \n";
    cout << "-------------------\n\n";
    for (int i = 0; i < cases; i++) {
        expected.getRow(i, expected_result);
        input.getRow(i, test);

        NN.predict(test, predicted, input_size);

        displayArray("Input: ", test, 1, input_size, false);
        displayArray("Expected Output: ", expected_result, 1, output_size, false);
        displayArray("Actual: ", predicted, 1, output_size, false);
        cout << endl;
    }

    //Shutdown the netwrok by saving its data and releasing all dynamic allocation
    NN.shutdown("NeuralNetworkData/NeuralNet.properties");

    // Clear allocated memory
    delete[] predicted;
    delete[] expected_result;
    delete[] test;

    // Get end time and display elapsed time
    auto end = chrono::system_clock::now();
    chrono::duration<double> elapsed = end - start;
    cout << "\n\n=============================";
    cout << "\nElapsed Time (sec): " << elapsed.count() << endl;
    cout << "=============================\n";
    
    return 0; // Return Success
}