#ifndef NEURAL_NETWORK_HPP
#define NEURAL_NETWORK_HPP

#include "Layer.hpp"
#include "ConnectedLayer.hpp"
#include "ActivationLayer.hpp"
#include <iostream>
#include <fstream>

using namespace std;

enum ReadResults{SUCCESS, FAILURE};

const int EPOCH_UPDATE_OCCURENCE = 100;

struct ConnectedList {
	ConnectedLayer layer;
	struct ConnectedList* next;
	struct ConnectedList* prev;
};

struct ActivationList {
	ActivationLayer layer;
	struct ActivationList* next;
	struct ActivationList* prev;
};

class NeuralNetwork{
	public:
		ConnectedList* conn_list = nullptr;
		ActivationList* act_list = nullptr;
	private:
		int ID = 0;
		int layer_cnt = 0;
		int final_output_cnt = 0;
		int initial_input_cnt = 0;
		double (*error)(double, double*, int) = nullptr;
		void (*error_prime)(double*, double*, double*, int) = nullptr;

	public:
		NeuralNetwork(string filename);

		NeuralNetwork(int ID, double (*error)(double, double*, int),
			void (*error_prime)(double*, double*, double*, int));

		void addConnectedLayer(ConnectedLayer conn_layer);

		void addActivationLayer(ActivationLayer act_layer);

		void clear();

		void display(bool show_detail=false);

		void predict(double* input, double* dst, int input_size);

		void setError(double (*error)(double, double*, int), void (*error_prime)(double*, double*, double*, int));
		
		void shutdown(string filename);

		void train(Matrix inputs, Matrix expected, int epochs, double learning_rate);

	private:
		ConnectedList* clearConnectedList(ConnectedList* localPtr);

		ActivationList* clearActivationList(ActivationList* localPtr);

		int load(string filename);

		void save(string filename);
};

#endif