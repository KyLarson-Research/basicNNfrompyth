#ifndef ACTIVATIONS_HPP
#define ACTIVATIONS_HPP

#include <math.h>

// Activation function definitions
double tan_hb(double input) {
	return tanh(input);
}

double tan_hb_prime(double input) {
	double temp = tanh(input);
	return 1 - (temp * temp);
}

double squared(double input) {
	return input * input;
}

double squaredPrime(double input) {
	return 2 * input;
}

#endif