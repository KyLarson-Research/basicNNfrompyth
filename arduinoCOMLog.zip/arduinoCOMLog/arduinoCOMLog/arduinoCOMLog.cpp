// arduinoCOMLog.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <windows.h>
#include <tchar.h>
#include <fstream>
using namespace std;

bool IsKeyPressed(unsigned timeout_ms = 0)
{
    return WaitForSingleObject(
        GetStdHandle(STD_INPUT_HANDLE),
        timeout_ms
    ) == WAIT_OBJECT_0;
}

int main()
{
    DCB dcb;
    int retVal;
    BYTE Byte;
    DWORD dwBytesTransferred;
    DWORD dwCommModemStatus;
    HANDLE hPort;
    ofstream myfile;
    
    char fstring[15] = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' };
    cout << "File Name to save data (max 14 characters):\n";
    cin >> fstring;
    myfile.open(fstring);
    
    
    hPort = CreateFile(_T("COM9"), // This changes based on the USB port so start here if you are debugging
        GENERIC_READ,
        0,
        NULL,
        OPEN_EXISTING,
        0,
        NULL);
    if (hPort == INVALID_HANDLE_VALUE) {
        std::cout << "error opening port, check your cables!";
    }//https://docs.microsoft.com/en-us/previous-versions/ff802693(v=msdn.10)?redirectedfrom=MSDN
    if (!GetCommState(hPort, &dcb))
        return 0x100;
    dcb.BaudRate = CBR_115200; //9600 Baud
    dcb.ByteSize = 8; //8 data bits
    dcb.Parity = NOPARITY; //no parity
    dcb.StopBits = ONESTOPBIT; //1 stop
    if (!SetCommState(hPort, &dcb))
        return 0x100;
    SetCommMask(hPort, EV_RXCHAR | EV_ERR); //receive character event
    WaitCommEvent(hPort, &dwCommModemStatus, 0); //wait for character
    if (dwCommModemStatus & EV_RXCHAR)
        ReadFile(hPort, &Byte, 1, &dwBytesTransferred, 0); //read 1
    else if (dwCommModemStatus & EV_ERR)
        retVal = 0x101;
    std::cout << "read from COM9 returned: ";
    //this reads a byte at a time until the user has had enough and presses key
    while (!IsKeyPressed(10)){
        ReadFile(hPort, &Byte, 1, &dwBytesTransferred, 0); //read 1
        std::cout <<  Byte;
        myfile << Byte;
    }

    CloseHandle(hPort);
    myfile.close();
    return retVal;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
